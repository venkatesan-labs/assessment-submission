import os
import requests
import psycopg2
import re
from psycopg2.extras import RealDictCursor
from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel
from typing import Optional

app = FastAPI(title="Assistant Service")

# 1. Catalog Service & LLM URLs
CATALOG_HOST = os.getenv("CATALOG_SERVICE_HOST", "catalog-service")
CATALOG_PORT = os.getenv("CATALOG_SERVICE_PORT", "8000")
CATALOG_SERVICE_URL = os.getenv("CATALOG_SERVICE_URL", f"http://{CATALOG_HOST}:{CATALOG_PORT}")

LLM_HOST = os.getenv("LLM_HOST", "qwen-model")
LLM_PORT = os.getenv("LLM_PORT", "8000")
LLM_SERVICE_URL = os.getenv("LLM_SERVICE_URL", f"http://{LLM_HOST}:{LLM_PORT}/v1/chat/completions")

DB_HOST = os.getenv("DB_HOST", "postgres")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "catalogdb")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")

# Pull system prompt from environment
SYSTEM_PROMPT = os.getenv("LLAMA_ARG_SYSTEM_PROMPT", "You are an e-commerce assistant. Answer customer questions accurately.")

CACHE_FILE = "catalog_cache.md"

def get_db_connection():
    return psycopg2.connect(host=DB_HOST, port=int(DB_PORT), database=DB_NAME, user=DB_USER, password=DB_PASSWORD)

@app.on_event("startup")
def init_db_and_cache():
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                username VARCHAR(100) NOT NULL,
                phone_number VARCHAR(50),
                ad_consent BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS chat_history (
                id SERIAL PRIMARY KEY,
                user_id INT REFERENCES users(id) ON DELETE CASCADE,
                sender VARCHAR(50) NOT NULL,
                message TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        conn.commit()
        cur.close()
        conn.close()
        print("Assistant database tables initialized successfully.")
    except Exception as e:
        print(f"Database initialization error: {e}")
    
    refresh_catalog_cache()

def refresh_catalog_cache():
    """Fetches catalog data once and caches it locally in FastAPI memory/markdown file."""
    try:
        res = requests.get(f"{CATALOG_SERVICE_URL}/items", timeout=10)
        if res.status_code == 200:
            items = res.json()
            categories = set(i.get('category', 'General') for i in items)
            
            md_content = f"# E-Commerce Catalog Cache\n\n"
            md_content += f"**Available Categories:** {', '.join(categories)}\n\n"
            md_content += f"## Items\n"
            
            for i in items:
                md_content += f"- [ID: {i['id']}] Name: {i['name']} | Note: {i.get('short_note')} | Cat: {i.get('category')} | Stock: {i['stock']} | Price: ${i['price']} | Specs: {i.get('specifications')}\n"
            
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                f.write(md_content)
            print("Catalog successfully cached to local markdown file.")
    except Exception as e:
        print(f"Failed to refresh catalog cache: {e}")

def get_cached_catalog_str() -> str:
    if not os.path.exists(CACHE_FILE):
        refresh_catalog_cache()
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            return f.read()
    return "Catalog information currently unavailable."

class AskRequest(BaseModel):
    question: str
    username: str
    phone: str
    ad_consent: bool = False
    item_id: Optional[int] = None

@app.get("/healthz")
def healthz():
    return {"status": "healthy"}

@app.get("/history")
def get_history(username: str, phone: str):
    try:
        conn = get_db_connection()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute("SELECT id FROM users WHERE username = %s AND phone_number = %s;", (username, phone))
        user = cur.fetchone()
        if not user:
            cur.close()
            conn.close()
            return []
        
        cur.execute("SELECT sender, message, timestamp FROM chat_history WHERE user_id = %s ORDER BY timestamp ASC;", (user['id'],))
        history = cur.fetchall()
        cur.close()
        conn.close()
        return history
    except Exception as e:
        return []

def get_or_create_user(username: str, phone: str, consent: bool) -> int:
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id FROM users WHERE username = %s AND phone_number = %s;", (username, phone))
    row = cur.fetchone()
    if row:
        user_id = row[0]
    else:
        cur.execute("""
            INSERT INTO users (username, phone_number, ad_consent)
            VALUES (%s, %s, %s) RETURNING id;
        """, (username, phone, consent))
        user_id = cur.fetchone()[0]
        conn.commit()
    cur.close()
    conn.close()
    return user_id

def log_message(user_id: int, sender: str, message: str):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO chat_history (user_id, sender, message) VALUES (%s, %s, %s);", (user_id, sender, message))
    conn.commit()
    cur.close()
    conn.close()

def call_llm(catalog_context: str, user_question: str) -> str:
    try:
        # Structure payload following system prompt instructions and cached catalog context
        payload = {
            "model": "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
            "messages": [
                {
                    "role": "system", 
                    "content": f"{SYSTEM_PROMPT}\n\nCatalog Reference Data:\n{catalog_context}"
                },
                {
                    "role": "user", 
                    "content": user_question
                }
            ],
            "temperature": 0.2
        }
        res = requests.post(LLM_SERVICE_URL, json=payload, timeout=120)
        if res.status_code == 200:
            data = res.json()
            return data.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
    except Exception as e:
        print(f"LLM call error exception: {e}")
    return "Information unavailable at the moment."

def format_customer_output(raw_text: str) -> str:
    if not raw_text:
        return ""
    
    text = raw_text.strip()
    text = re.sub(r'(:\s*)(\d+\.\s+)', r':\n\n\2', text)
    text = re.sub(r'\s+(\d+\.\s+)', r'\n\n\1', text)
    
    lines = text.split('\n')
    formatted_lines = []
    
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        if re.match(r'^\d+\.\s+', stripped):
            if not stripped.endswith('  '):
                stripped = stripped.rstrip() + '  '
        formatted_lines.append(stripped)
        
    return "\n".join(formatted_lines)

@app.post("/ask/")
def answer_question(req: AskRequest):
    user_id = get_or_create_user(req.username, req.phone, req.ad_consent)
    log_message(user_id, "user", req.question)

    # Read from local markdown cache
    catalog_str = get_cached_catalog_str()

    # Send to LLM with system prompt + catalog reference data
    raw_answer = call_llm(catalog_str, req.question)
    final_answer = format_customer_output(raw_answer)

    if not final_answer or len(final_answer) < 2:
        final_answer = "Information unsupported. Please ask questions related to our product catalog."

    log_message(user_id, "bot", final_answer)
    return {"answer": final_answer}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("assistant:app", host="0.0.0.0", port=8000, reload=True)