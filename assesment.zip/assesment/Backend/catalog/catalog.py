import os
import time
import psycopg2
from psycopg2.extras import RealDictCursor
from fastapi import FastAPI, HTTPException, status

app = FastAPI(title="Catalog Service")

DB_HOST = os.getenv("DB_HOST", "postgres")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "catalogdb")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")

def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST,
        port=int(DB_PORT),
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
    )

def init_and_seed_db():
    retries = 5
    while retries > 0:
        try:
            conn = get_db_connection()
            cur = conn.cursor()

            # Create items table with expanded schema
            cur.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(255) NOT NULL,
                    short_note VARCHAR(255),
                    description TEXT,
                    stock INT NOT NULL,
                    specifications TEXT,
                    category VARCHAR(100),
                    price NUMERIC(10, 2) NOT NULL
                );
            """)
            
            # Create user and chat history tables for the assistant backend reference
            cur.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id SERIAL PRIMARY KEY,
                    username VARCHAR(100) NOT NULL,
                    phone_number VARCHAR(20) NOT NULL,
                    ad_consent BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT unique_user UNIQUE (username, phone_number)
                );
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS chat_history (
                    id SERIAL PRIMARY KEY,
                    user_id INT REFERENCES users(id) ON DELETE CASCADE,
                    sender VARCHAR(10) NOT NULL,
                    message TEXT NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            conn.commit()

            cur.execute("SELECT COUNT(*) FROM items;")
            count = cur.fetchone()[0]

            if count == 0:
                print("Seeding exactly 20 explicitly defined catalog items...")
                
                # 20 explicit product records: (name, short_note, description, stock, specifications, category, price)
                items_to_seed = [
                    ("Matte Liquid Lipstick", "Long-lasting vibrant lip color.", "A smudge-proof matte liquid lipstick enriched with Vitamin E for all-day hydration and bold color payoff.", 42, "Volume: 5ml, Finish: Matte, Shade: Ruby Red", "Makeup", 18.99),
                    ("Hydrating Facial Cleanser", "Gentle daily cleanser for glowing skin.", "Formulated with ceramides and hyaluronic acid to cleanse without stripping natural moisture.", 15, "Volume: 200ml, Skin Type: All", "Skincare", 14.50),
                    ("Wireless Noise-Canceling Earbuds", "Immersive sound on the go.", "Compact wireless earbuds featuring active noise cancellation and 24-hour battery life via charging case.", 8, "Bluetooth 5.3, IPX4 Water Resistant", "Electronics", 79.99),
                    ("Minimalist Leather Wallet", "Slim profile genuine leather fold.", "Crafted from top-grain leather with RFID blocking technology and multiple card slots.", 23, "Material: Cowhide Leather, Slots: 6 Cards", "Accessories", 29.99),
                    ("Ergonomic Desk Lamp", "Adjustable LED lighting with USB port.", "Sleek touch-controlled desk lamp with 3 color temperature modes and adjustable brightness levels.", 12, "Power: 10W LED, Input: 5V/2A", "Home", 34.00),
                    ("Volumizing Mascara", "Lash-lifting curl formula.", "Clump-free brush design that coats every single lash for maximum volume and length.", 31, "Volume: 8ml, Color: Jet Black", "Makeup", 15.20),
                    ("Vitamin C Brightening Serum", "Fades dark spots and boosts radiance.", "Powerful antioxidant serum infused with 15% pure Vitamin C and ferulic acid.", 19, "Volume: 30ml, Key Active: L-Ascorbic Acid", "Skincare", 24.99),
                    ("Smart Fitness Watch", "Track steps, sleep, and heart rate.", "Lightweight fitness tracker with a vibrant AMOLED display and multi-sport workout modes.", 7, "Battery Life: 7 Days, Waterproof: 5ATM", "Electronics", 49.99),
                    ("Stainless Steel Travel Mug", "Keeps drinks hot or cold for hours.", "Double-wall vacuum insulated travel tumbler with a leak-proof flip lid.", 50, "Capacity: 500ml, Material: 18/8 Steel", "Home", 21.50),
                    ("Classic Canvas Backpack", "Durable everyday casual carryall.", "Spacious main compartment with a padded laptop sleeve and reinforced shoulder straps.", 14, "Capacity: 20L, Material: Heavy Canvas", "Accessories", 39.99),
                    ("Pressed Powder Palette", "Flawless touch-up setting powder.", "Silky smooth micronized powder that controls shine and blurs pores instantly.", 27, "Weight: 10g, Finish: Natural Translucent", "Makeup", 22.00),
                    ("Exfoliating Body Scrub", "Smoothing coffee and sugar scrub.", "Buffs away dry skin cells while nourishing your skin with organic coconut oil.", 11, "Weight: 250g, Scent: Vanilla Coffee", "Skincare", 17.50),
                    ("Portable Bluetooth Speaker", "Punchy bass in a pocket-sized body.", "Rugged water-resistant mini speaker designed for outdoor adventures and beach trips.", 22, "Playback: 6 Hours, Output: 5W", "Electronics", 32.50),
                    ("Silk Sleep Mask", "Pure mulberry silk for deep rest.", "Hypoallergenic ultra-soft eye mask designed to block out 100% of light completely.", 35, "Material: 100% Grade 6A Silk", "Home", 16.00),
                    ("Polarized Aviator Sunglasses", "Timeless style with UV400 protection.", "Lightweight metal frame sunglasses offering glare reduction and crystal-clear vision.", 18, "Lens: UV400 Polarized, Frame: Metal Alloy", "Accessories", 45.00),
                    ("Shimmer Highlighter Compact", "Instant lit-from-within glow.", "Finely milled reflective powder that melts effortlessly onto cheekbones and high points.", 25, "Weight: 7g, Shade: Golden Champagne", "Makeup", 19.50),
                    ("Nourishing Night Cream", "Deep overnight skin repair.", "Rich peptide-infused moisturizer that restores skin elasticity while you sleep.", 13, "Volume: 50ml, Skin Type: Dry/Combination", "Skincare", 28.00),
                    ("USB-C Fast Charging Hub", "Multi-port high-speed data adapter.", "Expands a single USB-C port into 3 USB 3.0 ports and an HDMI output.", 9, "Transfer Rate: 5Gbps, Support: 4K Video", "Electronics", 26.99),
                    ("Aromatherapy Essential Oil Diffuser", "Ultrasonic mist maker with ambient lights.", "Quiet humidifier and diffuser combo featuring auto shut-off safety protection.", 16, "Tank Capacity: 300ml, Run Time: 10 Hours", "Home", 35.99),
                    ("Geometric Metal Hair Claw", "Chic modern hair accessory.", "Sturdy metal claw clip designed to securely hold up thick hair with elegance.", 40, "Material: Zinc Alloy, Length: 11cm", "Accessories", 12.00)
                ]

                cur.executemany("""
                    INSERT INTO items (name, short_note, description, stock, specifications, category, price)
                    VALUES (%s, %s, %s, %s, %s, %s, %s);
                """, items_to_seed)
                conn.commit()
                print("Catalog seeding completed successfully with 20 items.")

            cur.close()
            conn.close()
            break
        except Exception as e:
            retries -= 1
            print(f"DB connection failed ({e}). Retrying in 3s... ({retries} left)")
            time.sleep(3)

@app.on_event("startup")
def startup_event():
    init_and_seed_db()

@app.get("/healthz/", status_code=status.HTTP_200_OK)
def healthz():
    return {"status": "healthy"}

@app.get("/items/")
def get_all_items():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("SELECT id, name, short_note, description, stock, specifications, category, price FROM items ORDER BY id ASC;")
    items = cur.fetchall()
    cur.close()
    conn.close()
    for item in items:
        item["price"] = float(item["price"])
    return items

@app.get("/items/{item_id}")
def get_item_by_id(item_id: int):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("SELECT id, name, short_note, description, stock, specifications, category, price FROM items WHERE id = %s;", (item_id,))
    item = cur.fetchone()
    cur.close()
    conn.close()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    item["price"] = float(item["price"])
    return item
if __name__ == "__main__":
    import uvicorn
    # This starts a blocking web server loop inside the Python code itself
    uvicorn.run("catalog:app", host="0.0.0.0", port=8000, reload=True)