const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 80;

// 1. Serve static frontend files from the 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// 2. Gateway Health Check -> Catalog Service /healthz
app.use('/healthz', createProxyMiddleware({
  target: (process.env.CATALOG_SERVICE_URL || 'http://catalog-service:8000') + '/healthz',
  changeOrigin: true
}));

// 3. Catalog API Proxy -> Catalog Service /items
app.use('/api/v1/items', createProxyMiddleware({
  target: (process.env.CATALOG_SERVICE_URL || 'http://catalog-service:8000') + '/items',
  changeOrigin: true
}));

// 4. Assistant API Proxy -> Assistant Service /answer
app.use('/api/v1/ask', createProxyMiddleware({
  target: (process.env.ASSISTANT_SERVICE_URL || 'http://assistant-service:8000') + '/ask',
  changeOrigin: true
}));

// 5. SPA Fallback: serve index.html for any unhandled browser route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Enterprise API Gateway running on port ${PORT}`);
});